from blogApp.forms import ArticuloForm, CardSearchForm
from django.test import TestCase
from django.urls import reverse
from django.contrib.auth.models import User
from blogApp.models import Articulo


class ArticuloModelTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        # Crea un usuario de prueba
        test_user = User.objects.create_user(username='admin', password='admin')
        test_user.save()

    def setUp(self):
        # Configuración inicial para cada prueba
        author = User.objects.get(id=1)
        self.articulo = Articulo.objects.create(
            title='Título de prueba',
            subtitle='Subtítulo de prueba',
            text='Texto de prueba',
            image='ruta/de/imagen.jpg',
            author=author
        )

    def test_title_max_length(self):
        max_length = self.articulo._meta.get_field('title').max_length
        self.assertEquals(max_length, 200)

    def test_subtitle_max_length(self):
        max_length = self.articulo._meta.get_field('subtitle').max_length
        self.assertEquals(max_length, 200)

    def test_text_blank(self):
        field = self.articulo._meta.get_field('text')
        self.assertTrue(field.blank)

    def test_image_upload_to(self):
        upload_to = self.articulo._meta.get_field('image').upload_to
        self.assertEquals(upload_to, 'articulo_images/')

    def test_str_representation(self):
        self.assertEquals(str(self.articulo), self.articulo.title)

    def test_author_relationship(self):
        author = self.articulo.author
        self.assertTrue(isinstance(author, User))
        self.assertEquals(author.username, 'testuser')

    def test_verbose_name(self):
        self.assertEquals(Articulo._meta.verbose_name, "Artículo")

    def test_verbose_name_plural(self):
        self.assertEquals(Articulo._meta.verbose_name_plural, "Artículos")


class ArticuloFormTest(TestCase):

    def test_form_fields(self):
        form = ArticuloForm()
        self.assertTrue('title' in form.fields)
        self.assertTrue('subtitle' in form.fields)
        self.assertTrue('text' in form.fields)
        self.assertTrue('image' in form.fields)

    def test_form_labels(self):
        form = ArticuloForm()
        self.assertEquals(form.fields['title'].label, 'Título')
        self.assertEquals(form.fields['subtitle'].label, 'Subtítulo')
        self.assertEquals(form.fields['text'].label, 'Texto del artículo')
        self.assertEquals(form.fields['image'].label, 'Imagen')


class CardSearchFormTest(TestCase):

    def test_form_fields(self):
        form = CardSearchForm()
        self.assertTrue('search_text' in form.fields)

    def test_form_labels(self):
        form = CardSearchForm()
        self.assertEquals(form.fields['search_text'].label, 'Search Text')

    def test_form_widgets(self):
        form = CardSearchForm()
        self.assertEquals(form.fields['search_text'].widget.attrs['placeholder'], 'Enter search text')

    def test_form_max_length(self):
        form = CardSearchForm()
        self.assertEquals(form.fields['search_text'].max_length, 100)

    def test_form_required(self):
        form = CardSearchForm()
        self.assertFalse(form.fields['search_text'].required)


class ArticuloListViewTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='admin', password='admin')
        self.articulo = Articulo.objects.create(title='Test Article', subtitle='Test Subtitle', text='Test Text',
                                                author=self.user)

    def test_articulo_list_view_with_search(self):
        response = self.client.get(reverse('articulo.list') + '?orden=title&search_text=Test')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Article')

    def test_articulo_list_view_without_search(self):
        response = self.client.get(reverse('articulo.list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Article')

    def test_articulo_list_view_invalid_search_form(self):
        response = self.client.get(reverse('articulo.list') + '?orden=title&search_text=')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Article')

    def test_articulo_list_view_with_invalid_order(self):
        response = self.client.get(reverse('articulo.list') + '?orden=invalid')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Article')


class ArticuloDetailViewTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='admin', password='admin')
        self.articulo = Articulo.objects.create(title='Test Article', subtitle='Test Subtitle', text='Test Text',
                                                author=self.user)

    def test_articulo_detail_view(self):
        response = self.client.get(reverse('articulo.detail', kwargs={'pk': self.articulo.pk}))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Article')


class ArticuloCreateViewTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='admin', password='admin')

    def test_articulo_create_view(self):
        self.client.login(username='admin', password='admin')
        response = self.client.post(reverse('articulo.new'),
                                    data={'title': 'New Article', 'subtitle': 'New Subtitle', 'text': 'New Text'})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Articulo.objects.filter(title='New Article').count(), 1)


class ArticuloUpdateViewTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='admin', password='admin')
        self.articulo = Articulo.objects.create(title='Test Article', subtitle='Test Subtitle', text='Test Text',
                                                author=self.user)

    def test_articulo_update_view(self):
        self.client.login(username='admin', password='admin')
        response = self.client.post(reverse('articulo.update', kwargs={'pk': self.articulo.pk}),
                                    data={'title': 'Updated Article'})
        self.assertEqual(response.status_code, 302)
        self.articulo.refresh_from_db()
        self.assertEqual(self.articulo.title, 'Updated Article')


class ArticuloDeleteViewTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='admin', password='admin')
        self.articulo = Articulo.objects.create(title='Test Article', subtitle='Test Subtitle', text='Test Text',
                                                author=self.user)

    def test_articulo_delete_view(self):
        self.client.login(username='admin', password='admin')
        response = self.client.post(reverse('articulo.delete', kwargs={'pk': self.articulo.pk}))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Articulo.objects.filter(title='Test Article').count(), 0)
